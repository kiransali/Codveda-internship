#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int main()
{
    int number,guess,attempts=0;
    srand(time(0));
    number=rand()%100+1;
    cout<<"guess the number(1 to 100)"<<endl;
    do
    {
        cin>>guess;
        attempts++;
        if(guess>number)
        cout<<"too high"<<endl;
        else if(guess<number)
        cout<<"too low"<<endl;
        else
        cout<<"correct guess"<<endl;
    }
    while(guess!=number);
    cout<<"attempts:"<<attempts<<endl;
    return 0;
}