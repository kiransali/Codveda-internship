 #include<iostream>
 using namespace std;
 int main()
 {
     int a,b;
     char c;
     cout<<"enter a=";cin>>a;
     cout<<"enter c=";cin>>c;
     cout<<"enter b=";cin>>b;
     if(c=='+')
     cout<<a+b;
     if(c=='-')
     cout<<a-b;
     if(c=='*')
     cout<<a*b;
     if(c=='/')
     {
         if(b==0)
         cout<<"no";
         else
         cout<<a/b;
     }
    if(c!='+'&&c!='-'&&c!='*'&&c!='/')
     cout<<"wrong";
     return 0;
     }